function varargout = como401_moverotate(h, x, R)

% function R = como401_moverotate(h, [x y z], R)
% move the object with handle h to position [x y z]
% and orient with euler angles R = [phi, theta, psi] or 
% or R can be a 3x3 rotation matrix
% children move too

u = get(h, 'userdata');

if numel(R)==3

% rotation matrices
Rpsi = [ 1      0         0          ;
         0   cos(R(3))  -sin(R(3))   ;
         0   sin(R(3))   cos(R(3))   ];


Rtheta = [ cos(R(2)) -sin(R(2))  0   ;
           sin(R(2))  cos(R(2))  0   ;
               0           0     1   ];

Rphi = [ 1      0         0          ;
         0   cos(R(1))  -sin(R(1))   ;
         0   sin(R(1))   cos(R(1))   ];

R = Rphi*Rtheta*Rpsi;

end
    

% translation vectors (are the rows of vtx)
vtx = ones(size(u.vertex))*diag(x);  % jth column = x(i)

set(h, 'vertices', u.vertex*R' + vtx);

for i=1:numel(u.child)
    uc = get(u.child(i), 'userdata');
    vtx = ones(size(uc.vertex))*diag(x);   % jth column = x(i)
    set(u.child(i), 'vertices', uc.vertex*R' + vtx);
end

if nargout>0
    varargout{1} = R;
end
