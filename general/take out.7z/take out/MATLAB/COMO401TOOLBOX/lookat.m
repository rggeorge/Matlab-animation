function lookat(target)

% function lookat(target)
% point camera at target
% target = [x y z] coordinates or handle of a patch object
%
% MGP March 2008

if numel(target)==1  % assume its the handle of a patch object
    target = mean(get(target, 'vertices'));
end

set(gca, 'cameratarget', target);