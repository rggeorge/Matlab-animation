function como401_move(h, x)

% function como401_move(h, x)
% move the object with handle h to position x = [x y z]
% children move too

u = get(h, 'userdata');
vtx = ones(size(u.vertex))*diag(x);  % jth column = x(i)
set(h, 'vertices', u.vertex + vtx);

for i=1:numel(u.child)
    uc = get(u.child(i), 'userdata');
    vtx = ones(size(uc.vertex))*diag(x);   % jth column = x(i)
    set(u.child(i), 'vertices', uc.vertex + vtx);
end
