function como401_mover(h, x)

% function como401_move(h, x)
% move the object with handle h to position x = [x y z]
% children move too (recursive version)

u = get(h, 'userdata');
vtx = ones(size(u.vertex))*diag(x);  % jth column = x(i)
set(h, 'vertices', u.vertex + vtx);

if isfield(u, 'child')
    for i=1:numel(u.child)
        como401_mover(u.child(i), x);
    end
end