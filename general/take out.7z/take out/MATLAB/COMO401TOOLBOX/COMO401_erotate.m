function varargout = COMO401_erotate(h,e)

% function COMO401_erotate(h, [phi, theta, psi])
% rotate object h using xzx euler angles
% nb rotation order is psi (x), e(2) (z), e(1) (x)
% MGP Feb 2008


Rpsi = [ 1      0         0          ;
         0   cos(e(3))  -sin(e(3)) ;
         0   sin(e(3))   cos(e(3))   ];


Rtheta = [ cos(e(2)) -sin(e(2)) 0;
           sin(e(2))  cos(e(2)) 0;
               0           0      1   ];

Rphi = [ 1      0         0    ;
       0   cos(e(1))  -sin(e(1)) ;
       0   sin(e(1))   cos(e(1))   ];

R = Rphi*Rtheta*Rpsi;

% rotate parent
u = get(h, 'userdata');
set(h, 'vertices', u.vertex*R');

% ... and children
for i=1:numel(u.child)
    uc = get(u.child(i), 'userdata');
    set(u.child(i), 'vertices', uc.vertex*R');
end

if nargout==1
    varargout{1} = R;
end


