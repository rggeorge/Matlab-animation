function COMO401_unlink(parent, child)

% function COMO401_unlink(parent, child)
% removes parent & child pointers for objects
% see also COMO401_unlink
% MGP Feb 2008

% child has only one parent, so we can remove it
COMO401_uset(child, 'parent', []);

% remove child from list of children
children = COMO401_uget(parent, 'child');
i = find(children==child);  % where is the child?
% overwrite child field, with specified child missing
COMO401_uset(parent, 'child', children([1:(i-1) (i+1):end]);  


