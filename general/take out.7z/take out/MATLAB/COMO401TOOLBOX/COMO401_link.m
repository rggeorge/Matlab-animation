function COMO401_link(parent, child)

% function COMO401_link(parent, child)
% sets parent & child pointers for objects
% see also COMO401_unlink
% MGP Feb 2008

% child has only one parent, so we can set it
COMO401_uset(child, 'parent', parent);

% parent may already have children, so need to append this child
children = [COMO401_uget(parent, 'child') child];
COMO401_uset(parent, 'child', children);


