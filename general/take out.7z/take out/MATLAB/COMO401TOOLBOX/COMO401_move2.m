function COMO401_move2(h, x, dt)

% function COMO401_move2(h, x, dt)
% translate object h along trajectory x (nx3) 
% with frame time dt (frame rate 1/dt)
%
% MGP Feb 2008

tic
for i=1:size(x,1)
    COMO401_move(h, x(i,:));
    drawnow
    while toc<i*dt, end
end
