function R = COMO401_matrotate(h, R)

% function COMO401_axrotate(h, R)
% rotate object h using rotation matrix R
% MGP Feb 2008

    % rotate parent
    u = get(h, 'userdata');
    set(h, 'vertices', u.vertex*R');

    % ... and children
    for i=1:numel(u.child)
        uc = get(u.child(i), 'userdata');
        set(u.child(i), 'vertices', uc.vertex*R');
    end
