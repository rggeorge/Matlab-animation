function h = octahedron(size, colour, e)

% function h = octahedron(size, colour, edges)
% octahedron patch object
% MGP Feb 2008

if nargin<3
    e = 'none';
end
if nargin<2
    colour = [1 1 1];
end
if nargin==0
    size=1;
end


v = [1 0 0; 0 1 0; 0 0 1; -1 0 0; 0 -1 0; 0 0 -1];
f = [1 2 3; 2 4 3; 4 5 3; 5 1 3; 6 1 5; 6 2 1; 6 4 2; 6 5 4];

h = patch('vertices', v, 'faces', f, ...
    'facecolor', colour, 'edgecolor', e);





