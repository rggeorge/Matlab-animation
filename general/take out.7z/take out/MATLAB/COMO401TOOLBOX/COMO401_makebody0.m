function COMO401_makebody0(h)

% function COMO401_makebody0(h)
% make patch object h into a body that can be moved
% at this point this means only attaching face-vertex data to userdata
% but later we will want to give objects more properties 
% (hence 'makebody0' not 'makebody')
%
% nb apply 'makebody' as soon as you create an object
%
% MGP Feb 2008

u.vertex = get(h, 'vertices');
u.child = [];
u.parent = [];
set(h, 'userdata', u);

