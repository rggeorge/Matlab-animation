function u = COMO401_uset(h, fieldname, value)

% function u = COMO401_uset(h, fieldname, value)
% set userdata field of h
% MGP Feb 2008

u = COMO401_uget(h);
u.(fieldname) = value;
set(h,'userdata', u);

