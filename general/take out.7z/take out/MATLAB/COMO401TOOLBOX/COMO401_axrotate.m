function R = COMO401_axrotate(h, theta, ax)

% function COMO401_axrotate(h, theta, ax)
% rotate object h through angle theta around axis ax = 'x', 'y' or 'z'
% MGP Feb 2008

       
switch ax
    case 'z'
       % matrix for rotation around z axis
       R = [ cos(theta) -sin(theta) 0; 
             sin(theta)  cos(theta) 0;
                 0           0      1   ]; 

    case 'x'
       % matrix for rotation around x axis
       R = [ 1      0         0          ; 
             0   cos(theta)  -sin(theta) ;
             0   sin(theta)   cos(theta)   ]; 

    case 'y'
       % matrix for rotation around y axis
       R = [ cos(theta)   0    sin(theta) ; 
                0         1        0      ;
            -sin(theta)   0    cos(theta)   ]; 

end

if ~isempty(h)  % can fetch rotation matrix without moving an object
    % rotate parent
    u = get(h, 'userdata');
    set(h, 'vertices', u.vertex*R');

    % ... and children
    for i=1:numel(u.child)
        uc = get(u.child(i), 'userdata');
        set(u.child(i), 'vertices', uc.vertex*R');
    end
end