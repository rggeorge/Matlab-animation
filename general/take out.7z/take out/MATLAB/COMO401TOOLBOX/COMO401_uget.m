function value = COMO401_uget(h, fieldname)

% function value = COMO401_uset(h, fieldname)
% get userdata field value from object h
% MGP Feb 2008

value = get(h, 'userdata');               % return userdata 
if nargin>1  & ~isempty(value)           
    value = getfield(value, fieldname);   %  ... or specified subfield
end

