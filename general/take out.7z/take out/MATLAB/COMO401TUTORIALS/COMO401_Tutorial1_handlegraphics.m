% COMO 401 Tutorial 1
% introduction to MATLAB patch objects
% MGP Feb 2008

clf

%% import gmax file as patch objects
% model has been exported from gmax in quake3 .md3 format
% import it as a set of patch objects and get their handles
% object names are listed as each is imported
handle = import_md3_2patch('chipmunk1.md3');

%% objects, handles and properties
% MATLAB figures contain objects that you see, and objects you don't see
% every object (including the figure itself) has a handle. A handle is 
% a unique number assigned to the object by MATLAB when it is created.

% WARNING: handle assignment is dynamic ... don't assume that an
% object has the same handle every time a script/function runs.

% Figure handles are always 1 for figure 1, 2 for figure 2 etc
% The function 'gcf' (get current figure) returns the handle 
% of the current figure (ie the figure which is at the 'front'
% or has the 'focus').  

% Similarly, 'gca' returns the handle of the current axes and 'gco'
% returns the handle of the current (selected) object.

% Objects are organized hierarchically within figures. You can find the 
% properties of an object using 'get'
get(gcf)

% Use 'get' to find the value of a particular property, e.g.
get(gcf, 'color')

% some properties, e.g. 'color', can be set. The following command lists
% only the settable properties of the figure
set(gcf)

% these properties can be set using e.g.
set(gcf, 'color', [0.5 0.75 1]) ; % blue sky

% Note that one of the properties of the figure is 'children'.
% This is a list of handles of objects in the figure
c = get(gcf, 'children');

% The figure has only one child
% Use 'get' to get its properties and try to figure out what it is
% (It's the handle of the axes)
get(c(1))

% Actually the figure has some other children. They are hidden
% because you normally don't need/want to know about them. 
% 'allchild' gets them
allchild(gcf)

% Every object also has a (unique) parent. The parent of the axes is
% the figure. The parent of the figure is the MATLAB workspace (handle 0).
% In summary, using set and get you can find your way around the hierarchy 
% of objects in a MATLAB figure window.

% Some object properties are automatically adjusted every time a scene
% is redrawn.  In particular this is true of axis limits and camera 
% properties.  We need to disable these auto-adjustments, otherwise the
% scene jumps around every time something moves in it.
% nb2 the toolbox function 'camfreeze' does this
set(gca, 'cameraviewanglemode', 'manual', ...
    'camerapositionmode', 'manual', ...
    'cameratargetmode', 'manual', ...
    'xlimmode', 'manual', ...
    'ylimmode', 'manual', ...
    'zlimmode', 'manual', ...    
    'dataaspectratio', [1 1 1], ...
    'visible', 'off');

view(-35, 35);
drawnow
hold on

% Each imported patch object is tagged with the name given in gmax.
% e.g. handle(1) is the handle of the left wing, handle(4) is right wing
get(handle(1), 'tag')
get(handle(4), 'tag')

% You can select an object in the scene, by clicking on it,
% and ask for its tag. In this demo I use 'set' to select objects
set(gcf, 'currentobject', handle(1)); % make left wing the current object
get(gco, 'tag');  % 'gco' is a shortcut for 'get(gcf, 'currentobject')'
set(gcf, 'currentobject', handle(4)); % current object is right wing
get(gco, 'tag');  

% It is convenient to give objects meaningful names. 
% I like to use data structures for hierarchical naming, e.g.
Chipmunk.wing.left = handle(1);
Chipmunk.wing.right = handle(4);

% I named the objects in gmax to match the required variable names
% in MATLAB. Then I can create variables using the tags, e.g.:
i = 1;
eval([ get(handle(i), 'tag')  ' = handle(' num2str(i) ');']);

% You can write a function to name all objects according to their tags.
% If you use 'eval' as above, new variables are confined to the function.
% (which is useless). To assign names in the workspace ('base'), 
% use 'evalin' as below (evalin is superfluous here because we are 
% in the base workspace already).
% nb the toolbox function 'nametags' does this
for i=1:numel(handle)
   evalin('base', [ get(handle(i), 'tag')  ' = handle(' num2str(i) ');']);
end

%% tidy up the rendering
% 
% nb use 'get' and 'set' to figure out what's in the scene and what you 
% can adjust. To start we'll make everything metallic gray & it is 
% convenenient ot refer to everything using 'handle'.
Color_metallic = [1 1 1]*.7;
for i=1:numel(handle)
set(handle(i), ...
    'facecolor', Color_metallic, ...
    'edgecolor', 'none')
end

% Use 'fieldnames' to find the fields and subfields of a structure
% and to loop over fields
fieldnames(Chipmunk)
propname = fieldnames(Chipmunk.propeller)
% make propeller components red
for i = 1:numel(propname)
    eval(['set(Chipmunk.propeller.' propname{i}, ...
           ', ''facecolor'' , [1 0 0] ) ; ' ]);
end

% make canopy glass translucent & highly reflective
set(Chipmunk.cockpit.glaze, 'facealpha', .3, 'specularstrength', 100);


% the right wing is now metallic gray, but it looks 'flat'.
% introduce a light 
Light1 = light;

% and a lighting model
% the default lighting model is 'flat', which is fast but shows each facet.
% I prefer gouraud lighting
% nb the lighting model is applied to objects in the scene at the time
%    if you add new objects they will have flat lighting
lighting flat
lighting phong
lighting gouraud

% lights can be adjusted in various ways
get(Light1)

% 'infinite' style means that 'position' is actually the direction to 
% a light source at infinity
get(Light1, 'position')

% move the light across the sky:
for t = -3:(1/60):3     % 1-minute increments, sunrise to sunset
    set(Light1, 'position', [ sin(-pi/2*t/6) 0 cos(-pi/2*t/6)]);
end

% The light jumped from 6am to 6pm even though we told it
% to go in 1-minute steps. This is because MATLAB buffers its graphics
% to avoid slowing calculations. 'drawnow' flushes the graphics buffer.
% So we try again:
% move the light across the sky:
for t = -3:(5/60):3     % 5-minute increments, 9am to 3pm
    set(Light1, 'position', [ sin(-pi/2*t/6) 0 cos(-pi/2*t/6)]);
    drawnow
end

% ground 
horizon = 100;
gridsize = 10;
% surf is an easy way to make a grid (or bumpy terrain)
surfground = surf(-horizon:gridsize:horizon, ...
              -horizon:gridsize:horizon, zeros(2*(horizon/gridsize)+1));
% but patch objects are easier to deal with in a 3D scene 
% (surf affects other surfaces in a scene). 
% So convert the surface to a patch object
groundFV = surf2patch(surfground);  % face-vertex data for ground
delete(surfground);                 % delete surface
% reconstruct as patch
ground = patch('faces', groundFV.faces, 'vertices', groundFV.vertices);
set(ground, 'facecolor', 'g', 'edgecolor', 'k')
xlim(horizon*[-1 1]);
ylim(horizon*[-1 1]);

% default projection is orthographic. change to perspective
set(gca, 'projection', 'perspective')


% axes
% vertical cylinder, radius 0.1. create with surf, convert to patch
% this is the z-axis
rc = .1;
[xc,yc,zc] = cylinder;  
surfax = surf(xc*rc, yc*rc, (zc-0.5)*2*horizon);
axFV = surf2patch(surfax);
delete(surfax);
zax = patch('faces', axFV.faces, 'vertices', axFV.vertices);
set(zax, 'facecolor', 'b', 'edgecolor', 'b');

% create x- and y-axes by permuting vertex data columns
% note the 'rgb' convention for xyz axes
xax = patch('faces', axFV.faces, 'vertices', axFV.vertices(:, [3 1 2]));
set(xax, 'facecolor', 'r', 'edgecolor', 'r');
yax = patch('faces', axFV.faces, 'vertices', axFV.vertices(:, [1 3 2]));
set(yax, 'facecolor', 'g', 'edgecolor', 'g');

lighting gouraud













