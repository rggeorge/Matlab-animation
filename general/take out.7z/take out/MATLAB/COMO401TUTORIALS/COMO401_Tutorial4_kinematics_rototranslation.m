% COMO 401 Tutorial
% rototranslation and pose
% MGP Feb 2008

% load the plane
% parts welded together, handle is 'plane'
COMO401_tutorial_loadplane;
camzoom(2)
% new function in toolbox: 
% 'lookat' points camera at [x y z], or a patch object
lookat([50 0 0]);
zlim([0 100])


% combine translation and rotation:
% function COMO401_moverotate(h, x, e) 
% combines translation (x = [x y z]) 
% and rotation with euler angles e = [phi theta psi]
COMO401_moverotate(plane, [10 0 2], [0 -pi/4 0]);
pause(1)

% reposition plane above origin
COMO401_moverotate(plane, [0 0 2], [0 0 0]);

% take off
% simple difference equation model of plane dynamics
% nb oversimplification of equations of motion 
%    but that's not the point.
% rostral acceleration a = amax*(vmax-v)/vmax
% specify orientation and acceleration at each time step
amax = 5;     % max accn m/s^2
vmax = 50;    % max velocity  m/s
dt = .05;     % time step
T = 8;        % duration, simulation time
t = dt:dt:T;
N = numel(t);  % number of time steps (number of elements in t)
v = [0 0 0];    % initial velocity
a = [0 0 0];   % initial acceleration
x = [0 0 2];   % initial position
h = [1 0 0];   % heading

% accelerate the plane in a straight line:
e = [0 0 0];    % maintain heading
tic
for i = 1:numel(t)
    
    % nb v is 1x3 velocity vector, norm(v) is speed, h is heading
    a = h*amax*(vmax-norm(v))/vmax; 
    v = v + a*dt;            % euler approximation dv/dt = a
    x = x + v*dt;            %   ""
    
    COMO401_moverotate(plane, x, e);
    drawnow
    while toc<t(i), end
    
end

% now climb  ...
% nb we are doing this kinematically, as is the state of the art in
% digital animation, by specifying a path and moving the object along it.
% as against dynamically = specifying equations of motion and controls.
e = [0 0 0];    % initial heading
R = eye(3);     % initial rotation matrix
% build climb profile
climax = pi/8;
climT  = 4;
climb  =  [ 0:dt:climT  climT:-dt:0]*climax/climT;  % nb +pitch is down!
climb  = [climb zeros(1, numel(t)-numel(climb)) ];   % pad with zeros 
    
% reinitialize
v = [0 0 0];    % initial velocity
a = [0 0 0];   % initial acceleration
x = [0 0 2];   % initial position
h = [1 0 0];   % heading

tic
for i = 1:numel(t)
      
    % nb v is 1x3 velocity vector, norm(v) is speed, h is heading
    h = R(:,1)';
    a = h*amax*(vmax-norm(v))/vmax; 
    v = v + a*dt;            % euler approximation dv/dt = a
    x = x + v*dt;            %   ""
    
    e = [pi/2 climb(i) -pi/2];
    
    R = COMO401_moverotate(plane, x, e);
    drawnow
    while toc<t(i), end
    
end

% ... and turn
T = 20;        % duration, simulation time
t = dt:dt:T;
% build climb profile
climax = pi/8;
climT  = 4;
climb  =  [ 0:dt:climT  climT:-dt:0]*climax/climT;  % nb +pitch is down!
climb  = [climb zeros(1, numel(t)-numel(climb)) ];   % pad with zeros 

e = [0 0 0];    % initial heading
R = eye(3);     % initial rotation matrix

dq = -pi/36;      % constant turn rate 2 deg/sec
    
% reinitialize
v = [0 0 0];    % initial velocity
a = [0 0 0];   % initial acceleration
x = [0 0 2];   % initial position
h = [1 0 0];   % initial heading
q = 0;         % turn angle
b = 0;         % bank angle
db = pi/64;
bmax = pi/8;

dragcoeff = .01;

xlim(500*[-1 1]);
ylim(500*[-1 1]);
camzoom(8)
tic
for i = 1:numel(t)
      
    % nb v is 1x3 velocity vector, norm(v) is speed, h is heading
    h = R(:,1)';
    a = h*amax*(vmax-norm(v))/vmax; 
    v = v*(1-dragcoeff) + a*dt;            % euler approximation dv/dt = a
    x = x + v*dt;            %   ""
    q = q + dq*dt;               % turn angle
    b = b + db*dt;
    b = min(b, bmax);
    
    
    Rturn  = como401_erotate(plane, [0 q 0]); % to get the turn mtx
    Rclimb = como401_erotate(plane, [pi/2 climb(i) -pi/2]); % climb mtx
    Rbank = como401_erotate(plane, [0 0 b]); % climb mtx
    
    
    R = COMO401_moverotate(plane, x, Rturn*Rclimb*Rbank);
    lookat(plane)
    drawnow
    while toc<t(i), end
    
end

% nb we have kluged something that looks plausible using simple 
% difference equations, without paying much attention to real aerodyanmics.
% We have only one rigid body, with 6 degrees of freedom of movement, but 
% already it is awkward and messy to control its motion this way.
% We want  physically correct animations of complex articulated structures.
% We will proceed by introducing (1) pose matrices as a computationally 
% convenient way to specify position and orientation, (2) the
% Denavit-Hartenberg convention for specifying the configuration of a 
% rigid body linkage and (3) analytical dynamics to derive equations of
% motion in terms of the dh configuration variables.

    