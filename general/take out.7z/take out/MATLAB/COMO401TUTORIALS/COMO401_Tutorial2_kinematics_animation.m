%% COMO 401 Tutorial 2
% kinematics and 3D animation in MATLAB
%
% run tutorial 1, to load the Chipmunk model, before running this
%
% MGP Feb 2008


hold on

%% translation 
% move the left wing 10 units in the x direction
dx = 20;
vertex0 = get(Chipmunk.wing.left, 'vertices');
nvertex = size(vertex0, 1);    % number of vertices 
dvertex = [dx*ones(nvertex,1) zeros(nvertex,2)];
set(Chipmunk.wing.left, 'vertices', ...
    vertex0 + dvertex );
drawnow
pause(1)

% ... and back
set(Chipmunk.wing.left, 'vertices', vertex0);

pause(1)

%% Animation
dt = .025;
T = 2;
w = .5;
a = 20;
for t = 0:dt:T
    x = a*sin(2*pi*w*t);
    vertexpos = [x*ones(nvertex,1) zeros(nvertex,2)];
    set(Chipmunk.wing.left, 'vertices', vertex0+vertexpos);
    drawnow
    pause(dt)
end

pause(1)


%% animate a set of objects
% make the whole plane move in the y direction
for i=1:numel(handle)
    % store initial vertex data in a cell array
    vertex{i}= get(handle(i), 'vertices');  
    nvtx(i)= size(vertex{i},1);
end
for t = 0:dt:T
    x = a*sin(-2*pi*w*t);
    for i=1:numel(handle)
    vertexpos = [zeros(nvtx(i),1) x*ones(nvtx(i),1) zeros(nvtx(i),1) ];
    set(handle(i), 'vertices', vertex{i}+vertexpos);
    end
    drawnow
    pause(dt)
end

pause(1)

%% synch animation to real time
tic  % start real time clock
for t = 0:dt:T
    x = a*sin(-2*pi*w*t);
    for i=1:numel(handle)
    vertexpos = [zeros(nvtx(i),1) x*ones(nvtx(i),1) zeros(nvtx(i),1) ];
    set(handle(i), 'vertices', vertex{i}+vertexpos);
    end
    drawnow
    while toc<t, end    % wait until real time = frame time
end
endtime = toc;

% check ratio of true frame rate to nominal frame rate
% this is useful to check that what you see corresponds to the 
% numerically specified trajectory.
disp(['animation rate: ' num2str(endtime/T) ])

pause(1)

%% check timing of every frame
% This is a weak check - different frames may render at different
% rates, especially under Windows. The following checks every frame time:
waited = 0;      % flag to check that the wait loop is executed
nowaitcount = 0; % counter for number of times wait loop is skipped
tic  % start real time clock
for t = 0:dt:T
    x = a*sin(-2*pi*w*t);
    for i=1:numel(handle)
    vertexpos = [zeros(nvtx(i),1) x*ones(nvtx(i),1) zeros(nvtx(i),1) ];
    set(handle(i), 'vertices', vertex{i}+vertexpos);
    end
    drawnow
    while toc<t, waited = 1; end    % set flag & wait
    if ~waited
        nowaitcount = nowaitcount+1;
    end
end

% how many times was frame time behind real time
nowaitcount

pause(1)

%% welding the plane together
% it is convenient to have a single handle for the whole plane
% and a function e.g. 'move(h, x)' that moves the object with handle h
% to position x. 
%
% To use the 'move' function we need to (1) weld the parts of the plane
%     into a single lump with one handle, and (2) record the initial 
%     vertex data for each piece(as in vertex{i}, above)
%     
% (1) choose one object to be the parent and create pointers that define
% the other parts as its children. When the move function moves an
% object it will move its children, too.
% MATLAB handle graphics objects have a spare field, called 'userdata' 
% that we can use for this purpose. 
plane = Chipmunk.propeller.spinner;  % spinner will be the parent object
uplane.child = [];                   % empty data struc field
uchild.parent = plane;               % data struc with pointer
for i=1:numel(handle)
    if handle(i)~=plane  % except for the spinner itself ...
        uplane.child = [uplane.child handle(i)];
        set(handle(i), 'userdata', uchild);  % give child its parent
    end
    set(plane, 'userdata', uplane);  % give plane its children
end

% (2) store initial vertex data for each object
% note we update existing userdata, don't replace it
for i=1:numel(handle)
    u = get(handle(i), 'userdata');
    u.vertex = get(handle(i), 'vertices');
    set(handle(i), 'userdata', u);
end

% the move function is in the COMO401 tutorial folder
% & is called COMO401_move
COMO401_move(plane, [10 0 0])
pause(1)
COMO401_move(plane, [0 0 0])
pause (1)

% function COMO401_move2 translates the object on a trajectory
% with frame time dt (frame rate 1/dt)
dt = .005;     % frame time
T = 3;        % length of animation /sec
t = dt:dt:T;  % frame times
ax = 10;
ay = 10;
az = 5;
w = 1;
% a trajectory ...
x = [ax*sin(2*pi*w*t') ay*t'.*cos(2*pi*w*t') az*(1+sin(2*pi*w*t'))];
COMO401_move2(plane, x, dt)

% move plane back to the origin
pause(1)
COMO401_move(plane, [0 0 0]);










        










