% COMO 401 Tutorial 1
% load the plane model & reposition it with x-axis through plane axis
% MGP Feb 2008

clf
handle = import_md3_2patch('chipmunk1.md3');

set(gca, 'cameraviewanglemode', 'manual', ...
    'camerapositionmode', 'manual', ...
    'cameratargetmode', 'manual', ...
    'xlimmode', 'manual', ...
    'ylimmode', 'manual', ...
    'zlimmode', 'manual', ...    
    'dataaspectratio', [1 1 1], ...
    'visible', 'off');

view(-35, 35);
drawnow
hold on

% name all objects according to their tags.
for i=1:numel(handle)
   evalin('base', [ get(handle(i), 'tag')  ' = handle(' num2str(i) ');']);
end

%% tidy up the rendering

% nb use 'get' and 'set' to figure out what's in the scene and what you 
% can adjust. To start we'll make everything metallic gray & it is 
% convenenient ot refer to everything using 'handle'.
Color_metallic = [1 1 1]*.7;
for i=1:numel(handle)
set(handle(i), ...
    'facecolor', Color_metallic, ...
    'edgecolor', 'none')
end

% Use 'fieldnames' to find the fields and subfields of a structure
% and to loop over fields
fieldnames(Chipmunk)
propname = fieldnames(Chipmunk.propeller)
% make propeller components red
for i = 1:numel(propname)
    eval(['set(Chipmunk.propeller.' propname{i}, ...
           ', ''facecolor'' , [1 0 0] ) ; ' ]);
end

% make canopy glass translucent & highly reflective
set(Chipmunk.cockpit.glaze, 'facealpha', .3, 'specularstrength', 100);


% the right wing is now metallic gray, but it looks 'flat'.
% introduce a light 
Light1 = light;

% lighting model
lighting gouraud

% ground 
horizon = 100;
gridsize = 10;
% surf is an easy way to make a grid (or bumpy terrain)
surfground = surf(-horizon:gridsize:horizon, ...
              -horizon:gridsize:horizon, zeros(2*(horizon/gridsize)+1));
% but patch objects are easier to deal with in a 3D scene 
% (surf affects other surfaces in a scene). 
% So convert the surface to a patch object
groundFV = surf2patch(surfground);  % face-vertex data for ground
delete(surfground);                 % delete surface
% reconstruct as patch
ground = patch('faces', groundFV.faces, 'vertices', groundFV.vertices);
set(ground, 'facecolor', 'g', 'edgecolor', 'k')
xlim(horizon*[-1 1]);
ylim(horizon*[-1 1]);

% default projection is orthographic. change to perspective
set(gca, 'projection', 'perspective')


% axes
% vertical cylinder, radius 0.1. create with surf, convert to patch
% this is the z-axis
rc = .1;
[xc,yc,zc] = cylinder;  
surfax = surf(xc*rc, yc*rc, (zc-0.5)*2*horizon);
axFV = surf2patch(surfax);
delete(surfax);
zax = patch('faces', axFV.faces, 'vertices', axFV.vertices);
set(zax, 'facecolor', 'b', 'edgecolor', 'b');

% create x- and y-axes by permuting vertex data columns
% note the 'rgb' convention for xyz axes
xax = patch('faces', axFV.faces, 'vertices', axFV.vertices(:, [3 1 2]));
set(xax, 'facecolor', 'r', 'edgecolor', 'r');
yax = patch('faces', axFV.faces, 'vertices', axFV.vertices(:, [1 3 2]));
set(yax, 'facecolor', 'g', 'edgecolor', 'g');

lighting gouraud

% connect plane into a single body with spinner as the parent
% nb we could write a function 'weld' to loop over fieldnames and
% connect the components of the plane. 
plane = Chipmunk.propeller.spinner;  % spinner will be the parent object
COMO401_makebody0(plane);            % set up rigid body properties
for i=1:numel(handle)
    if handle(i)~=plane  % except for the spinner itself ...
        COMO401_link(plane, handle(i));
        COMO401_makebody0(handle(i));
    end
end

% align x-axis with plane axis
v = COMO401_uget(plane, 'vertex'); % spinner vertices
z0 = mean(v(:,3));                 % height of spinner axis
COMO401_move(plane, [0 0 -z0]);    % align spinner with y-axis
% reset vertex data in this position
for i = 1:numel(handle)
    COMO401_uset(handle(i), 'vertex', get(handle(i), 'vertices'));
end

% rotate plane onto x-axis
como401_erotate(plane, [0 pi/2 0]);
% reset vertex data in this position
for i = 1:numel(handle)
    COMO401_uset(handle(i), 'vertex', get(handle(i), 'vertices'));
end

% put the plane back where it was
COMO401_move(plane, [0 0 z0]);    % align spinner with y-axis

view(35, 35);  % change the viewpoint

% now we can apply the move and erotate functions to the plane
% pause(1);
% COMO401_move(plane, [10 0 0]), pause(1)
% COMO401_move(plane, [0 0 0]), pause(1)
% COMO401_erotate(plane, [0, 0, pi/4]), pause(1), 
% COMO401_erotate(plane, [0, 0, 0]), pause(1)
% COMO401_erotate(plane, [0, pi/4, 0]), pause(1), 
% COMO401_erotate(plane, [0, 0, 0]), pause(1)
% COMO401_erotate(plane, [pi/4, 0, 0]), pause(1), 
% COMO401_erotate(plane, [0, 0, 0]), pause(1)








