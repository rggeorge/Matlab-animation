% COMO 401 Tutorial
% 3D rotation
% run tutorials 1 & 2 first
% MGP Feb 2008

% load the plane
% parts welded together, handle is 'plane'
COMO401_tutorial_loadplane0;
camzoom(6)
pause(1)

%% 2D rotation is easy
% rotate in the x-y plane (ie around z axis)

theta = pi/4;
% rotation by theta in x-y plane is 
%     x = x*cos(theta) - y*sin(theta)
%     y = x*sin(theta) + y*cos(theta)
%     z = z
% 
% so the 3D rotation matrix is:
R = [ cos(theta) -sin(theta) 0; 
      sin(theta)  cos(theta) 0;
          0           0      1 ];

% note columns of R give coordinates of rotated unit basis vectors 
% e.g. column 1 gives coordinates of [1 0 0]' rotated by theta

% to rotate an object around z:
u = get(Chipmunk.wing.right, 'userdata');
set(Chipmunk.wing.right, 'vertices', u.vertex*R')
pause(1)
set(Chipmunk.wing.right, 'vertices', u.vertex)

% animate ...
dt = .01;
T = 1;
t = dt:dt:T;
w = 1;
tic
for i = 1:numel(t)
    theta = 2*pi*w*t(i);
    R = [ cos(theta) -sin(theta) 0; 
          sin(theta)  cos(theta) 0;
              0           0            1   ];
    set(Chipmunk.wing.right, 'vertices', u.vertex*R');
    drawnow
    while toc<i*dt, end
end
pause(1)

% COMO401_axrotate(h, theta, axis)
% rotates object h & its children
% through angle theta around specified axis 'x', 'y' or 'z'
set(ground, 'visible', 'off'); % make ground invisible

% around x ...
for i = 1:numel(t)
    COMO401_axrotate(plane, 2*pi*w*t(i), 'x');
    drawnow
    while toc<i*dt, end
end
pause(1)

% around y ...
for i = 1:numel(t)
    COMO401_axrotate(plane, 2*pi*w*t(i), 'y');
    drawnow
    while toc<i*dt, end
end
pause(1)

% around z ...
for i = 1:numel(t)
    COMO401_axrotate(plane, 2*pi*w*t(i), 'z');
    drawnow
    while toc<i*dt, end
end
pause(1)

% the plane will be easier to fly if we align it with the rotation axes
u = get(Chipmunk.propeller.spinner, 'userdata');
sp = mean(u.vertex);  % location of the spinner
COMO401_move(plane, [0 0 -sp(3)]); % move plane so y-axis goes thru spinner
% reset the stored vertex data in this position
for i = 1:numel(handle)
    u = get(handle(i), 'userdata');
    u.vertex = get(handle(i), 'vertices');
    set(handle(i), 'userdata', u);
end
pause(1)
COMO401_axrotate(plane, pi/2, 'z');  % turn it to head along +x
% reset the stored vertex data in this position
for i = 1:numel(handle)
    u = get(handle(i), 'userdata');
    u.vertex = get(handle(i), 'vertices');
    set(handle(i), 'userdata', u);
end
pause(1)
view(35, 35);  % change the viewpoint
zlim([-10 10])
pause(1)

% now do those rotations again
% around x ...
for i = 1:numel(t)
    COMO401_axrotate(plane, 2*pi*w*t(i), 'x');
    drawnow
    while toc<i*dt, end
end
pause(1)

% around y ...
for i = 1:numel(t)
    COMO401_axrotate(plane, 2*pi*w*t(i), 'y');
    drawnow
    while toc<i*dt, end
end
pause(1)

% around z ...
for i = 1:numel(t)
    COMO401_axrotate(plane, 2*pi*w*t(i), 'z');
    drawnow
    while toc<i*dt, end
end
pause(1)

% rotations around x, y and z correspond to roll, pitch and yaw
% but in general these are specified in a frame that moves with the
% plane, e.g. pitch is the angle of the plane's main axis wrt ground, 
Ryaw = COMO401_axrotate(plane, pi/4, 'z');
pause(1)
Rpch = COMO401_axrotate(plane, -pi/4, 'y');
pause(1)

% function COMO401_matrotate(h,R) rotates an object using 
% rotation matrix R
% Combining yaw and pitch 
for rep = 1:3
    COMO401_matrotate(plane, Rpch*Ryaw)
    pause(1)
    % gives (a) the wrong pitch and (b) a different result if we change order
    COMO401_matrotate(plane, Ryaw*Rpch)
    pause(1)
end

% specifying orientation using rotations around x, y and z is difficult
% It's generally simpler to use Euler angles
% You can specify an arbitrary orientation in 3D in terms of rotation
% around one axis, followed by rotation around another, then rotation 
% around the first axis again. The angles are Euler angles. We will use
% xzx-Euler angles (later we will see that this makes it relatively easy 
% to implement the standard convention for specifying joint angles in 
% robotics)

% roll is easy:
alpha = pi/4;
for i = 1:numel(t)
    COMO401_erotate(plane, [alpha*sin(2*pi*w*t(i)), 0, 0]);
    drawnow
    while toc<i*dt, end
end
pause(1)

% so is yaw:
for i = 1:numel(t)
    COMO401_erotate(plane, [0, alpha*sin(2*pi*w*t(i)), 0]);
    drawnow
    while toc<i*dt, end
end
pause(1)

% pitch is a bit trickier:

% around x ...
for i = 1:numel(t)
    COMO401_erotate(plane, [0, 0, pi*t(i)/2]);
    drawnow
    while toc<i*dt, end
end
pause(1)

% around z ...
for i = 1:numel(t)
    COMO401_erotate(plane, [0, -alpha*t(i), pi/2]);
    drawnow
    while toc<i*dt, end
end
pause(1)

% around x again ...
for i = 1:numel(t)
    COMO401_erotate(plane, [-pi*t(i)/2, -alpha, pi/2]);
    drawnow
    while toc<i*dt, end
end
pause(1)

% so, pitch control:
COMO401_erotate(plane, [0, 0, 0]);
pause(1)
for j = 1:4
    for i = 1:numel(t)
        COMO401_erotate(plane, [-pi/2, -alpha*sin(2*pi*t(i)), pi/2]);
        drawnow
        while toc<i*dt, end
    end
end



