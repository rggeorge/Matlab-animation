function xdot = pend_odefcn(t,x,p)

% function xdot = pend_odefcn(t,x,p)
% ode function for a simple pendulum
% q'' + (g/r)sin(q) = 0
% xdot = [x(2); -9.81/p.r*sin(x(1))]
% MGP April 2008

xdot = [x(2); -9.81/p.r*sin(x(1))];

