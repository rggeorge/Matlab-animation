% math 474 2008
% how to use MATLAB ode solvers
% MGP April 2008

clf
clear

% function draw_pendulum(q,p) draws a pendulum 
% at angle q from vertical
% nb handle is returned and used in subsequent calls
p.r = 4;    % pendulum length
p.d = .2;   % bob radius
q = 0;
p = draw_pendulum(q, p); 

% ode solvers require xdot = odefcn(t,x,p)
% which returns state derivative as a function of state
% (& time t & parameter p)
% the ode for a pendulum is q'' + (g/r)sin(q) = 0
% in state-space form xdot = [x(2); -(g/r) sin(x(1))]
% this is implemented in pend_odefcn 

% Standard ode solver is ode45
% see help ode45 for usage, & other solvers
% Here I call it to solve the pendulum equation for 10 seconds
% starting with pendulumn at rest at angle pi/8
% pend_odefcn (and NB! all other functions called within ode45 )
% is called with arguments (t,x,p)
% the 4th argument is solver options, making it empty tells the solver 
% to use its default arguments
T = 10;
q0 = pi/8;
X = ode45(@pend_odefcn, [0 T], [q0 0], [], p)

% independent variable is returned as X.x (always time, t, in our models)
% dependent (state) is X.y (the state, usually we use x)
% so we'd prefer X.t and X.x instead of X.x and X.y 
% but this is built in to MATLAB & not worth changing

% the time points X.x are chosen by the solver algorithm 
% (in this case the Runge-Kutta 4-5 order adaptive stepsize algorithm)
% to meet the specified accuracy options
% to animate, we want the configuration (ie x(1)) at regular intervals
dt = .05;        % frame interval  (1/dt is frame rate)
t = 0:dt:T;      % time vector - we want the solution at these times
x = deval(t,X);  % interpolates to get state at requested times

% state is N x numel(t) where N is state dimension 
% ie there is one row for each state variable
size(x)

% animate
% (we've done this before)
tic % start realtime clock
for i = 1:numel(t)
    
    draw_pendulum(x(1,i), p); 
    
    drawnow
    
    while toc<i*dt, end
    
end

    



