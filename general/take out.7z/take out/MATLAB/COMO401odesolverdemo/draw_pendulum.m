function p = draw_pendulum(q,p)

% function p = draw_pendulum(q,p)
% draw simple pendulum 
% q = angle (theta)
% p.r = pendulum length
% p.d = pendulum bob radius
%
% handle of pendulum is returned as p.handle
% 
% MGP Apr 2008

% draw new pendulum if it does not exist
if ~isfield(p, 'handle') % could use findobj('tag', 'pendulum')
    
    clf
    c = plot([-1 1], [0 0 ]); set(c, 'linewidth', 2);
    xlim(p.r*[-1 1])
    ylim([round(-(p.r+1)) 1]);
    hold on
    p.x = [0 0 p.d 0 -p.d 0];
    p.y = [0 -p.r+p.d -p.r -p.r-p.d -p.r -p.r+p.d];
    p.handle = plot(p.x,p.y);
    set(p.handle, 'linewidth', 2);
    set(p.handle, 'tag', 'pendulum');
    daspect([1 1 1])
end

set(p.handle, 'xdata', cos(q)*p.x - sin(q)*p.y);
set(p.handle, 'ydata', sin(q)*p.x + cos(q)*p.y);



