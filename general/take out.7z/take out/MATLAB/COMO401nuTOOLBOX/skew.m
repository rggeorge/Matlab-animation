function S = skew(X)

% function S = skew(X)
% skew(X) = X-X'
% MGP Aug 2004

S = X-X';