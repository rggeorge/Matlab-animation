function even = iseven(x)

% is x an even integer?

even=floor(x/2)*2==x;