function hideonly(h)

% function hide(h)
% hide rigidbody 
% MGP June 2004

set(h, 'visible', 'off');
