function p = parent(h)

% function p = parent(h)
% h should have one parent
% MGP Oct 2004

p = uget(h, 'parent');