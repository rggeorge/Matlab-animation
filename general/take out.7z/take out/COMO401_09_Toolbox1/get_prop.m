function output = get_prop(obj, prop)


u = get(obj, 'userdata');
if nargin<2
    output = u;
else
    try 
        output = u.(prop);
    catch
        output = NaN;
    end
end