function output = position(obj, secondarg, thirdarg)

u = get(obj, 'userdata');
parent = u.parent;

switch nargin
    case 1
        output = u.pose;
    case 2
        elseif numel(secondarg)==1
            output = P_q*u.DH;
        else
            
        end
        
        
end