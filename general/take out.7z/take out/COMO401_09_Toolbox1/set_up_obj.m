function rigidbody(object)

u.vertices = get(object, 'vertices');
u.parent = [];
u.child = [];
set(Skull, 'userdata', u);