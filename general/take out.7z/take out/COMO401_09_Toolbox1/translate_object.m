function translate_object(obj, new_pos)

u = get(obj, 'userdata');

length = size(u.vertices, 1);
trans_matrix = ones(length, 1)*new_pos;
new_vertices = u.vertices + trans_matrix;
set(obj, 'vertices', new_vertices);

child = get_user_data(obj, 'child');
for n = 1:numel(child)
    translate_object(child(n), new_pos);
end