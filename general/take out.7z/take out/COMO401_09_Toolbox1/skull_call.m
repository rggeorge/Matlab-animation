%retrieve skull, set up animation

clear
clf

asc2fig('skull_to_import.asc');
daspect([1 1 1]);
c = get(gca, 'children');
set(c, 'EdgeColor', 'none');
L = light;
lighting gouraud
camfreeze

bone_color = [0.9412    0.9451    0.8039];
tooth_color = [0.9882    0.9882    0.9490];
eye_color = [1.0000    0.9686    0.9686];

set([Skull Mandible], 'FaceColor', bone_color);
set([Upperteeth Lowerteeth], 'FaceColor', tooth_color);
set([LeftEye RightEye], 'FaceColor', eye_color);
set([JawAxis Pivotpt Lec Rec], 'Visible', 'off')

objects = {'Skull', 'Mandible', 'Upperteeth', 'Lowerteeth', 'RightEye', 'LeftEye'};


for j = 1:numel(objects)
    rigidbody(eval(objects{j}), objects{j});
end

for k = 2:numel(objects)
    assign_child(Skull, eval(objects{k}));
end
assign_child(Mandible, Lowerteeth)

pose(Skull, r4([-pi/2 -pi/2 -pi/2], [-.18 .11 0]));

for j = 1:numel(objects)
    rigidbody(eval(objects{j}), objects{j});
end

for k = 2:numel(objects)
    assign_child(Skull, eval(objects{k}));
end
axwidget;
assign_child(Mandible, Lowerteeth)


cube1 = makecube(.01);
rigidbody(cube1);
pose(cube1,r4([0 0 pi/2], [-.2 -.35  0 ]));

cube2 = makecube(.01);
rigidbody(cube2);
pose(cube2,r4([pi/2 pi/2 pi], [-.2 -.35  0 ]));
assign_child(cube1, cube2);
assign_child(cube2, Skull);
for j = 1:numel(objects)
    rigidbody(eval(objects{j}), objects{j});
end
assign_child(cube2, Skull);
for k = 2:numel(objects)
    assign_child(Skull, eval(objects{k}));
end
