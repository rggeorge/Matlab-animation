function DH_mat = DH(q,d,a,alpha)
qmat = [cos(q) -sin(q); sin(q) cos(q)];
DHq = [qmat zeros(2); zeros(2) eye(2)];

DHd = eye(4);
DHd(3,4) = d;

DHa = eye(4);
DHa(1,4) = a;

DHalpha = [1 0 0 0; 0 cos(alpha) -sin(alpha) 0;
           0 sin(alpha) cos(alpha) 0 ; 0 0 0 1];
       
DH_mat = DHq*DHd*DHa*DHalpha;