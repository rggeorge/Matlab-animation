function new_v_array = moveto(object, dest_coords)
m = size(get(object, 'Vertices'),1);
shift_array = ones(m, 1)*dest_coords;
new_v_array = shift_array + get(object, 'Vertices');