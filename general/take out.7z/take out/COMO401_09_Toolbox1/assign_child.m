function assign_child(parent, child)

former_child = get_user_data(parent, 'child');
new_child = [former_child   child];
set_user_data(parent, 'child', new_child);

set_user_data(child, 'parent', parent);
set_user_data(child, 'pose', eye(4));
parent_pose_rel2world = pose(parent);
old_vertices = [get(child, 'vertices')'; ones(1,size(get(child, 'vertices'), 1))];
new_vertices = inv(parent_pose_rel2world)*old_vertices;
set_user_data(child, 'vertices', new_vertices);